Tikslus360 version 1.0.0
==============================

Tikslus360 is a jquery plugin to view image in 360 degree mode with following features:

Simple and elagant 360 image view
Javascript CANVAS based
Move cursor horizontally in both directions to rotate viwe
Click & Drag to Zoom Image
Auto rotate image


We have put all the plugins files in Plugins folder.
You can use Plugins folder directly in your projects.

visit http://tikslus.com/tikslus360/demo for a demo.
visit http://tikslus.com/tikslus360/docs for plugin documentation
